//
//  bill24Sdk.h
//  bill24Sdk
//
//  Created by San Vivorth on 11/3/21.
//

#import <Foundation/Foundation.h>
//! Project version number for bill24Sdk.
FOUNDATION_EXPORT double bill24SdkVersionNumber;

//! Project version string for bill24Sdk.
FOUNDATION_EXPORT const unsigned char bill24SdkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <bill24Sdk/PublicHeader.h>

